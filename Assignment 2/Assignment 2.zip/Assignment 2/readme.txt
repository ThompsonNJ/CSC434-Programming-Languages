lexical_analyzer.py is assignment 1.
recognizer.py imports lexical_analyzer.py to tokenize the strings.